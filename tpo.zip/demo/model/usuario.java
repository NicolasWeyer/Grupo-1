package com.tpo.demo.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.neo4j.core.schema.*;

import java.util.Collection;
import java.util.Set;

@Node
public class usuario {
    @Id
    private Long id;
    private String name;

    @Relationship(type = "SIGUE_A", direction = Relationship.Direction.OUTGOING)
    private Set<usuario> siguiendo;

    public Long id() {
        return id;
    }

    public String name() {
        return name;
    }

    public Collection<? extends usuario> siguiendo() {
        return siguiendo.toArray(new usuario[siguiendo.size()]);
    }

    public boolean findPath(usuario start, usuario target, Set<Long> visited) {
        if (start.equals(target)) {
            System.out.println("Path found to: " + target.name());
            return true;
        }

        visited.add(start.id());

        for (usuario follower : start.siguiendo()) {
            if (!visited.contains(follower.id()) && findPath(follower, target, visited)) {
                return true;
            }
        }

        visited.remove(start.id());
        return false;
    }

    public boolean findShortestPath(usuario start, usuario target, int depth, int maxDepth, Set<Long> visited) {
        if (depth > maxDepth) return false;
        if (start.equals(target)) {
            System.out.println("Path found to: " + target.name() + " at depth: " + depth);
            return true;
        }

        visited.add(start.id());

        for (usuario follower : start.siguiendo()) {
            if (!visited.contains(follower.id()) && findShortestPath(follower, target, depth + 1, maxDepth, visited)) {
                return true;
            }
        }

        visited.remove(start.id());
        return false;
        // Getters y setters
    }
}