package com.tpo.demo.controller;
import org.springframework.web.bind.annotation.*;
import com.tpo.demo.repository.usuarioRepository;
import com.tpo.demo.model.*;

@RestController
@RequestMapping("/usuarios")
public class usuarioController {
    private final usuarioRepository usuarioRepository;

    public usuarioController(usuarioRepository userRepository) {
        this.usuarioRepository = userRepository;
    }

    @PutMapping
    public usuario createUser(@RequestBody usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    @GetMapping("/{name}")
    public usuario getUser(@PathVariable String name) {
        return usuarioRepository.findByName(name);
    }
}
