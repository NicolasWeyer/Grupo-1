package com.tpo.demo.controller;
import com.tpo.demo.model.usuario;
import org.springframework.data.annotation.Id;
import org.springframework.data.neo4j.core.schema.*;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class arboles {
    public void dfs(usuario user, Set<Long> visited) {
        if (visited.contains(user.id())) return;
        visited.add(user.id());
        System.out.println("Visited: " + user.name());
        for (usuario follower : user.siguiendo()) {
            dfs(follower, visited);
        }
    }
    public void bfs(usuario startusuario) {
        Queue<usuario> queue = new LinkedList<>();
        Set<usuario> visited = new HashSet<>();
        queue.add(startusuario);

        while (!queue.isEmpty()) {
            usuario usuario = queue.poll();
            if (visited.contains(usuario.id())) continue;

            visited.add(usuario);
            System.out.println("Visited: " + usuario.name());

            queue.addAll(usuario.siguiendo());
        }
    }
}