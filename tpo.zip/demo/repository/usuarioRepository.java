package com.tpo.demo.repository;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import com.tpo.demo.model.*;
public interface usuarioRepository extends Neo4jRepository<usuario, Long> {
    usuario findByName(String name);
}